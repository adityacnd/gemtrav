<?php

	$server = "localhost";
	$username = "id20834836_sayabang";
	$password = "Manager44$";
	$database = "id20834836_gemilang";
	
	$koneksi = mysqli_connect($server, $username, $password, $database) or die("Koneksi ke database gagal");